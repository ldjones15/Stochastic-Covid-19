for k = 1    
    % Create the output file name.
    folder = sprintf('%s/PACT Output_noContent - phase 7/%s', pwd, strSystems{k});
    baseFileName = sprintf('%s_results.xml ',strSystems{k});
    fullFileName = fullfile(folder, baseFileName);
    fprintf('About to try to open file: "%s".', fullFileName);
    % Open the file.
    fid = fopen(fullFileName,'wt');
    if fid == -1
        % Some kind of problem opening the file.  Alert the user.
        errorMessage = sprintf('Error creating file:\n%s', fullFileName);
        fprintf('%s\n', errorMessage);
        uiwait(warndlg(errorMessage));
        continue; % Skip the rest of this loop.
    end
    % If you get here, the file was oepned successfully.  Now write something to it.
    fprintf(fid, 'blah blah blah fubar snafu whatever.\n')
    % Close the file.  We are done with it now.
    fclose(fid);
    fprintf('Successfully created file: "%s".', fullFileName);
end